//
//  SettingsView.swift
//  Bop
//
//  Created by Justin Hurley on 2/19/21.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        Text("Settings")
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
