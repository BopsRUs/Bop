//
//  SocialView.swift
//  Bop
//
//  Created by Justin Hurley on 2/17/21.
//

import SwiftUI

struct SocialView: View {
    var body: some View {
        Text("Social")
    }
}

struct SocialView_Previews: PreviewProvider {
    static var previews: some View {
        SocialView()
    }
}
