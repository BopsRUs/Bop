//  This file was automatically generated and should not be edited.

import AWSAppSync